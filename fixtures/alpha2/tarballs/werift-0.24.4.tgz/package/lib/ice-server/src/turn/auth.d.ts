export declare function makeTurnIntegrityKey(username: string, realm: string, password: string): Buffer<ArrayBufferLike>;
