export declare function serializeSimpleBlock(frame: Buffer, isKeyframe: boolean, trackNumber: number, relativeTimestamp: number): Buffer<ArrayBuffer>;
export interface SimpleBlock {
    data: Buffer;
    trackNumber: number;
    isKeyframe: boolean;
    timecode: number;
}
export declare function deserializeSimpleBlocks(data: Buffer): SimpleBlock[];
