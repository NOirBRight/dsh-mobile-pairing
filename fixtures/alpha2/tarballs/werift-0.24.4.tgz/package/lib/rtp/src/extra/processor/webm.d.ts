import { Event } from "../../imports/common";
import type { WebmSupportedCodec } from "../container/webm";
import type { AVProcessor } from "./interface";
export interface WebmTrack {
    width?: number;
    height?: number;
    roll?: number;
    kind: MediaKind;
    codec: WebmSupportedCodec;
    clockRate: number;
    trackNumber: number;
}
export type WebmInput = {
    frame?: {
        data: Buffer;
        isKeyframe: boolean;
        /**ms */
        time: number;
    };
    eol?: boolean;
};
export interface WebmOutput {
    saveToFile?: Buffer;
    kind?: "initial" | "cluster" | "block" | "cuePoints";
    /**ms */
    previousDuration?: number;
    eol?: {
        /**ms */
        duration: number;
        durationElement: Uint8Array;
        header: Buffer;
    };
}
export interface WebmOption {
    /**ms */
    duration?: number;
    encryptionKey?: Buffer;
    strictTimestamp?: boolean;
}
export declare class WebmBase implements AVProcessor<WebmInput> {
    tracks: WebmTrack[];
    private output;
    private options;
    private builder;
    private relativeTimestamp;
    private timestamps;
    private cuePoints;
    private position;
    private clusterCounts;
    /**ms */
    elapsed?: number;
    audioStopped: boolean;
    videoStopped: boolean;
    stopped: boolean;
    videoKeyframeReceived: boolean;
    internalStats: {};
    onStopped: Event<any[]>;
    constructor(tracks: WebmTrack[], output: (output: WebmOutput) => void, options?: WebmOption);
    toJSON(): Record<string, any>;
    private processInput;
    processAudioInput: (input: WebmInput) => void;
    processVideoInput: (input: WebmInput) => void;
    protected start(): void;
    private onFrameReceived;
    private createCluster;
    private createSimpleBlock;
    stop(): void;
}
/**4294967295 */
export declare const Max32Uint: number;
/**32767 */
export declare const MaxSinged16Int: number;
export declare const DurationPosition = 83;
export declare const SegmentSizePosition = 40;
export declare function replaceSegmentSize(totalFileSize: number): Buffer<ArrayBuffer>;
export type MediaKind = "video" | "audio";
