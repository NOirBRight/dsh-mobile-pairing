import { RtcpHeader } from "../rtcp/header";
import { RtpHeader } from "../rtp/rtp";
export declare function parseSrtpRtpHeader(packet: Buffer, authTagLength: number, message?: string): RtpHeader;
export declare function parseSrtcpHeader(packet: Buffer, authTagLength: number, srtcpIndexSize: number, message?: string): RtcpHeader;
export declare function finalizeSrtpRtpHeader(header: RtpHeader, packet: Buffer, message?: string): RtpHeader;
