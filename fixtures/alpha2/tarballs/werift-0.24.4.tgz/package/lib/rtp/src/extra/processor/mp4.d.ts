import { Event } from "../../imports/common";
import { type DataType, type Mp4SupportedCodec } from "../container/mp4";
import type { AVProcessor } from "./interface";
export type Mp4Input = {
    frame?: {
        data: Buffer;
        isKeyframe: boolean;
        /**ms */
        time: number;
    };
    eol?: boolean;
};
export type Mp4Output = {
    type: DataType;
    timestamp: number;
    duration: number;
    data: Uint8Array;
    eol?: false | undefined;
    kind: "audio" | "video";
} | {
    eol: true;
};
export interface MP4Option {
    /**ms */
    duration?: number;
    encryptionKey?: Buffer;
    strictTimestamp?: boolean;
}
export declare class MP4Base implements AVProcessor<Mp4Input> {
    tracks: Track[];
    private output;
    private options;
    audioStopped: boolean;
    private internalStats;
    private container;
    stopped: boolean;
    onStopped: Event<any[]>;
    videoStopped: boolean;
    constructor(tracks: Track[], output: (output: Mp4Output) => void | Promise<void>, options?: MP4Option);
    toJSON(): Record<string, any>;
    processVideoInput: ({ eol, frame }: Mp4Input) => void;
    processAudioInput: ({ eol, frame }: Mp4Input) => void;
    protected start(): void;
    stop(): Promise<void>;
}
export interface Track {
    width?: number;
    height?: number;
    kind: "audio" | "video";
    codec: Mp4SupportedCodec;
    clockRate: number;
    trackNumber: number;
}
