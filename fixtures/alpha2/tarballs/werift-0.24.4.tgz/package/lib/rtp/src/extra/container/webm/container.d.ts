import * as EBML from "./ebml";
export declare class WEBMContainer {
    readonly ebmlHeader: Uint8Array<ArrayBufferLike>;
    trackEntries: EBML.EBMLData[];
    private trackIvs;
    trackKeyIds: {
        [trackNumber: number]: Buffer;
    };
    encryptionKey?: Buffer;
    readonly encryptionKeyID: Buffer<ArrayBufferLike>;
    constructor(tracks: {
        width?: number;
        height?: number;
        roll?: number;
        kind: "audio" | "video";
        codec: WebmSupportedCodec;
        trackNumber: number;
    }[], encryptionKey?: Buffer);
    createTrackEntry(kind: string, trackNumber: number, codec: string, { width, height, roll, }?: Partial<{
        kind: string;
        width: number;
        roll: number;
        height: number;
    }>): EBML.EBMLData;
    createSegment(
    /**ms */
    duration?: number): Uint8Array<ArrayBufferLike>;
    createDuration(
    /**ms */
    duration: number): Uint8Array<ArrayBufferLike>;
    createCuePoint(relativeTimestamp: number, trackNumber: number, clusterPosition: number, blockNumber: number): EBML.EBMLData;
    createCues(cuePoints: EBML.EBMLData[]): Uint8Array<ArrayBufferLike>;
    createCluster(timecode: number): Uint8Array<ArrayBufferLike>;
    createSimpleBlock(frame: Buffer, isKeyframe: boolean, trackNumber: number, relativeTimestamp: number): Buffer<ArrayBuffer>;
}
export declare const containerSupportedCodecs: readonly ["MPEG4/ISO/AVC", "VP8", "VP9", "AV1", "OPUS"];
export type WebmSupportedCodec = (typeof containerSupportedCodecs)[number];
