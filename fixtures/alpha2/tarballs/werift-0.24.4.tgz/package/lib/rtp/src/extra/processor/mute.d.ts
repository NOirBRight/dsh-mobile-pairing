import type { DepacketizerOutput } from "./depacketizer";
import type { Processor } from "./interface";
export type MuteInput = DepacketizerOutput;
export type MuteOutput = MuteInput;
export declare class MuteHandlerBase implements Processor<MuteInput, MuteOutput> {
    private output;
    private props;
    readonly id: string;
    private buffer;
    private index;
    private ended;
    private baseTime?;
    private currentTimestamp;
    private internalStats;
    /**ms */
    private lastCommittedTime;
    private lastExecutionTime;
    /**ms */
    private interval;
    private bufferDuration;
    private bufferLength;
    /**ms */
    private lastFrameReceivedAt;
    constructor(output: (o: MuteOutput) => void, props: {
        ptime: number;
        dummyPacket: Buffer;
        /**ms
         * @description intervalごとに無音区間に空パケットを挿入する
         */
        interval: number;
        bufferLength: number;
    });
    toJSON(): Record<string, any>;
    private executeTask;
    private stop;
    processInput: ({ frame, eol }: MuteInput) => MuteOutput[];
}
