import { ReadableStream, WritableStream } from "stream/web";
import type { WebmSupportedCodec } from "../container/webm/container";
import { WebmBase, type WebmInput, type WebmOption, type WebmOutput } from "./webm";
export type WebmStreamOutput = WebmOutput;
export type WebmStreamOption = WebmOption;
export declare class WebmStream extends WebmBase {
    audioStream: WritableStream<WebmInput>;
    videoStream: WritableStream<WebmInput>;
    webmStream: ReadableStream<WebmStreamOutput>;
    private controller;
    constructor(tracks: {
        width?: number;
        height?: number;
        kind: "audio" | "video";
        codec: WebmSupportedCodec;
        clockRate: number;
        trackNumber: number;
    }[], options?: WebmStreamOption);
}
