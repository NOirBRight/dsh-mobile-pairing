export interface EBMLData {
    write(buf: Uint8Array, pos: number): number;
    countSize(): number;
}
export declare class Value implements EBMLData {
    bytes: Uint8Array;
    constructor(bytes: Uint8Array);
    write(buf: Uint8Array, pos: number): number;
    countSize(): number;
}
export declare class Element implements EBMLData {
    private id;
    private children;
    private readonly size;
    private readonly sizeMetaData;
    constructor(id: Uint8Array, children: EBMLData[], isSizeUnknown: boolean);
    write(buf: Uint8Array, pos: number): number;
    countSize(): number;
}
export declare const bytes: (data: Uint8Array) => Value;
export declare const number: (num: number) => Value;
export declare const float: (num: number) => Value;
export declare const vintEncodedNumber: (num: number) => Value;
/**
 * Decode a vint-encoded unsigned integer previously produced by `vintEncodedNumber`.
 * Returns its numeric value (number if within MAX_SAFE_INTEGER, otherwise bigint) and the length in bytes.
 * Throws if the value is the EBML unknown-size sentinel.
 */
export declare const decodeVintEncodedNumber: (buf: Uint8Array, offset?: number) => {
    value: number | bigint;
    length: number;
};
export declare const string: (str: string) => Value;
export declare const element: (id: Uint8Array, child: EBMLData | EBMLData[]) => EBMLData;
export declare const unknownSizeElement: (id: Uint8Array, child: EBMLData | EBMLData[]) => EBMLData;
export declare const build: (v: EBMLData) => Uint8Array;
export declare const getEBMLByteLength: (num: number | bigint) => number;
export declare const UNKNOWN_SIZE: Uint8Array<ArrayBuffer>;
export declare const vintEncode: (byteArray: Uint8Array) => Uint8Array;
export declare const getSizeMask: (byteLength: number) => number;
export interface VIntDecodeResult {
    /** The decoded value. Undefined if the VINT represents an unknown size sentinel (all value bits = 1). */
    value: number | bigint | undefined;
    /** Total number of bytes consumed by this VINT. */
    length: number;
    /** True when this VINT encodes the EBML "unknown size" value (all value bits set to 1). */
    unknown: boolean;
}
/**
 * Decode an EBML variable size integer (VINT) from the provided buffer.
 *
 * Encoding recap (EBML spec):
 *   The length (N, 1..8) is indicated by the position of the first set bit in the first byte.
 *   Patterns:
 *     1xxxxxxx -> 1 byte total  (7 value bits)
 *     01xxxxxx xxxxxxxx -> 2 bytes total (14 value bits)
 *     001xxxxx ...... -> 3 bytes total (21 value bits)
 *     ...
 *     00000001 [7 subsequent bytes] -> 8 bytes total (56 value bits)
 *
 * The marker bit itself is cleared from the first byte to recover the value bits.
 * Total value bits = 7 * N.
 * A value with all value bits set to 1 is reserved for the "unknown size" sentinel.
 */
export declare const vintDecode: (buf: Uint8Array, offset?: number) => VIntDecodeResult;
