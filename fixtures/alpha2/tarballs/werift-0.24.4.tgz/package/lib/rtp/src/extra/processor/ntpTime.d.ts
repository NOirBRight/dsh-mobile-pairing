import { type RtcpPacket, type RtpPacket } from "../..";
import type { Processor } from "./interface";
export type NtpTimeInput = {
    rtp?: RtpPacket;
    eol?: boolean;
    rtcp?: RtcpPacket;
};
export interface NtpTimeOutput {
    rtp?: RtpPacket;
    /**ms */
    time?: number;
    eol?: boolean;
}
export declare class NtpTimeBase implements Processor<NtpTimeInput, NtpTimeOutput> {
    clockRate: number;
    readonly id: string;
    private baseNtpTimestamp?;
    private baseRtpTimestamp?;
    private latestNtpTimestamp?;
    private latestRtpTimestamp?;
    private currentElapsed;
    private buffer;
    private internalStats;
    started: boolean;
    constructor(clockRate: number);
    toJSON(): Record<string, any>;
    private stop;
    processInput({ rtcp, rtp, eol }: NtpTimeInput): NtpTimeOutput[];
    /**
     *
     * @param rtpTimestamp
     * @returns sec
     */
    private calcNtp;
    private updateNtp;
}
