import type { DepacketizerOutput } from "./depacketizer";
import type { Processor } from "./interface";
export type DtxInput = DepacketizerOutput;
export type DtxOutput = DtxInput;
export declare class DtxBase implements Processor<DtxInput, DtxOutput> {
    ptime: number;
    private dummyPacket;
    readonly id: string;
    previousTimestamp?: number;
    private fillCount;
    private internalStats;
    constructor(ptime: number, dummyPacket: Buffer);
    toJSON(): Record<string, any>;
    processInput({ frame, eol }: DtxInput): DtxOutput[];
    private stop;
}
