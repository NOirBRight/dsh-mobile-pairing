/** Public API of @dsh-mobile/e2e-tunnel. */
export { connect, generateClientKeypair, openSession, publicEndpointSocketUrl, TunnelSession } from './client.ts';
export type { ClientKeypair, ConnectOptions, OpenSessionOptions, TunnelClient, TunnelState } from './client.ts';
export { parseOffer } from './offer.ts';
export type { DirectOffer, Offer, ParseOfferOptions, PublicEndpointCapabilities, PublicEndpointOffer, RelayOffer } from './offer.ts';
export { TunnelError, DEFAULT_MAX_HTTP_BODY_BYTES } from './errors.ts';
export type { TunnelErrorDetails } from './errors.ts';
export { connectionAttempts } from './connection-policy.ts';
export type { ConnectionPolicy, ConnectionRoute, RouteCapabilities } from './connection-policy.ts';
export { ConnectionCoordinator, DEFAULT_DIRECT_GRACE_MS } from './connection-manager.ts';
export type { ConnectionCoordinatorOptions, ConnectionPhase, ConnectionStatus } from './connection-manager.ts';
export { HeartbeatController } from './heartbeat.ts';
export type { HeartbeatOptions, HeartbeatScheduler, HeartbeatTarget } from './heartbeat.ts';
export { TunnelWebSocket } from './socket.ts';
export type { WebSocketLike } from './socket.ts';
export { WsFrameTransport, DataChannelTransport, fragmentFrame, FrameReassembler, fragmentRelayFrame, RelayFrameReassembler, MAX_MESSAGE_BYTES, MAX_RELAY_MESSAGE_BYTES, MAX_FRAME_BYTES } from './transport.ts';
export type { FrameTransport, DataChannelLike } from './transport.ts';
export { negotiateDirectChannel, encodeSignal, decodeSignal, TUNNEL_CHANNEL_LABEL } from './signal.ts';
export type { SdpSignal, SignalingSocket, PeerConnectionLike, NegotiateOptions, NegotiatedChannel } from './signal.ts';
export { b64urlEncode, b64urlDecode } from './bytes.ts';
export { compactDisplayName } from './display-name.ts';
//# sourceMappingURL=index.d.ts.map